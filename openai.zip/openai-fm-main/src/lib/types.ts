export interface LibraryEntry {
  name: string;
  input: string;
  prompt: string;
  voice: string;
}

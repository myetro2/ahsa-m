import ClientDynamicTTS from "@/components/ClientDynamicTTS";

export default function Page() {
  return <ClientDynamicTTS />;
}
